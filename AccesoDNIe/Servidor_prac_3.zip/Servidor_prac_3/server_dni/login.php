<?php 
require_once("seguridad.php"); 
require_once("BD.php");
@session_start(); 

?> 
<html> 
<head> 
<title>Autenticación</title> 
<link rel="stylesheet" type="text/css" href="form_ini.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
</head> 
<body> 
<br>
<h1>Usuario autenticado correctamente!</h1><br>
<h2>Sus datos:</h2> 
<h4>Usuario: <?php echo $_SESSION["usuarioactual"] ?> </h4>
<h4>DNI: <?php echo $_SESSION["dni"] ?> </h4><br> <br><br>



<a href="logout.php"><h4>Salir</h4></a> 
</body> 
</html>