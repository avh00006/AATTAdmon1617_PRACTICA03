<?php
session_start();
require_once("Usuarios.php");
require_once("BD.php");

	$conexion = conectar_MySQL( "localhost", "root", "", "dni_user" );

if (isset($_POST['chk'])){
  

	
		// insertar una persona:
	
	$ok = insertarPersona( $conexion, null, $_POST['nombre'], $_POST['password'] );

	if( $ok == false )
		echo "Error al resgistrarse.<br/>";
	else
		echo"<script>alert('Se ha registrado correctamente!'); window.location.href=\"index.php\"</script>";

	
	
} else {
	
/* El query valida si el usuario ingresado existe en la base de datos. Se utiliza la función htmlentities para evitar inyecciones SQL. */ 
$myusuario = mysql_query("select id from usuarios where usuario = '".htmlentities($_POST["nombre"])."'",$conexion); 
$nmyusuario = mysql_num_rows($myusuario); 

//Si existe el usuario, validamos también la contraseña ingresada 
if($nmyusuario != 0)
{ 
  $sql = "select id from usuarios where clave = '".htmlentities($_POST["password"])."'"; 
  $myclave = mysql_query($sql,$conexion); 
  $nmyclave = mysql_num_rows($myclave); 
  
   	$nom = $_POST["nombre"];	
  	$sql = "SELECT id FROM usuarios where usuario ='$nom'"; 
	$recupero = mysql_query($sql, $conexion) or die(mysql_error()); 
	$rec_id="";  
	while ($row_tb=mysql_fetch_assoc($recupero)) 
		{  
		$rec_id = ($row_tb['id']."");  
		}
  //Si el usuario y clave ingresado son correctos (y el usuario está activo en la BD), creamos la sesión del mismo. 
  if($nmyclave != 0)
  {
 
      session_start(); 
	  
      //Guardamos dos variables de sesión que nos auxiliará para saber si se está o no "logueado" un usuario 
      $_SESSION["autentica"] = "SIP"; 
      $_SESSION["usuarioactual"] = $_POST["nombre"]; 
      $_SESSION["dni"] = $_POST["password"]; 
      $_SESSION["id"] = "$rec_id";
      //nombre del usuario logueado. 
      //Direccionamos a nuestra página principal del sistema. 
      header ("Location: login.php"); 
   }
   else{ 
      echo"<script>alert('La contrase\u00f1a del usuario no es correcta.'); window.location.href=\"index.php\"</script>"; 
   } 
}
else
{ 
    echo"<script>alert('El usuario no existe.'); window.location.href=\"index.php\"</script>"; 
} 
mysql_close($conexion);

}

		
    
?>
