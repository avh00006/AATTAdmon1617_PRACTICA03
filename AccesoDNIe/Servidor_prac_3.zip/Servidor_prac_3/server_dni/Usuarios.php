<?php
	require_once("BD.php");
    class Usuario
    {
    	
        // Propiedades
        private $id = null;
        private $nombre  = null;
        private $clave = null;

       

  function __construct($id,$nom,$clav)
  {
    $this->id=$id;
    $this->nombre=$nom;
    $this->clave=$clav;
	
  }

   function insertarPersona( $conexion, $id, $nombre, $clave )
	{
		$sql = "INSERT INTO usuarios (usuario, clave) VALUES ('".$nombre."', '".$clave."')";

		// Ejecutamos la consulta (se devolverá true o false):
		return mysql_query( $sql, $conexion );
	}
	
	
        

	}   
	
	

    
?>
