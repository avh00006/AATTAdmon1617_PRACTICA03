

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

		<title>Autenticación DNIe</title>
		<link rel="stylesheet" type="text/css" href="form_ini.css">

	</head>

	<body>
		<div id='banner'>
            
            <h2>Pr&aacute;ctica 3. Implementaci&oacute;n de un servicio b&aacute;sico de autenticaci&oacute;n con DNIe</h2>
            <h3>Autenticación con los datos públicos del DNIe</h3>
            <h3>Aplicaciones telemáticas para la administración</h3>
            <h4> 
			<img src="uja.png" align="right"> ALUMNO: ANGEL VENTEO HERAS
			</h4>

        </div>
		<section class="container">
			<div class="login">
<h1>Autenticación DNIe</h1> <br /><br />
<form action="Menu.php" method="post">
<input name="chk" type="checkbox"/> Soy un nuevo usuario<br />
<h4>Usuario</h4> 
<input type="text" size="10" maxlength="16" name="nombre"/><br />
<h4>Clave</h4> 
<input type="password" size="16" name="password"/> <br /> <br />
<input type="submit" value="Log In" name="login"/>
</form>
</div>
</section>
	</body>
</html>