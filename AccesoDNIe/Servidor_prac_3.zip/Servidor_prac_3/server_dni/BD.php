<?php

	// Con esta línea mostramos los posibles errores:
	ini_set("display_errors", "off");
	ini_set("display_startup_errors", "off");

	// ----------------------------------------------

    function conectar_MySQL( $host, $user, $pass, $bd )
    {
        $conexion = null;

        try
        {
            // Conectar con MySQL:
            $conexion = mysql_connect( $host, $user, $pass );

            if( $conexion )
            {
                // Seleccionar a la base de datos deseada:
                if( mysql_select_db($bd) == false )
                    throw new Exception( "Error MySQL ".mysql_errno().": ".mysql_error() );
            }
            else
                throw new Exception( "Error MySQL ".mysql_errno().": ".mysql_error() );
        }
        catch( Exception $e )
        {
            throw $e;
        }

        return $conexion;
    }
	

	// ----------------------------------------------
 
   function insertarPersona( $conexion, $id, $nombre, $clave )
	{
		$sql = "INSERT INTO usuarios (usuario, clave) VALUES ('".$nombre."', '".$clave."')";

		// Ejecutamos la consulta (se devolverá true o false):
		return mysql_query( $sql, $conexion );
	}
	
	

?>